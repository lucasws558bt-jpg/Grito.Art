# Grito.Art (PWA)

## Publicar no GitHub Pages (uma vez)
1. Crie um repositório no GitHub (ex.: `grito-art`), público.
2. Envie todos os arquivos desta pasta para a raiz do repositório (arrastar e soltar em *Add file → Upload files* funciona).
3. Em **Settings → Pages**: *Source* = **Deploy from a branch**, *Branch* = **main** / **(root)** → Save.
4. Após ~1 min o app estará em `https://SEU-USUARIO.github.io/grito-art/`.

## Instalar no Android
Abra o link no Chrome → **⋮ → Instalar app**.

## Atualizar
Substitua o `index.html` no repositório (Upload files → mesmo nome → Commit).
Ao abrir o app com internet, ele baixa a versão nova e recarrega sozinho; sem internet, usa a última salva.
Se mudar ícones/manifest, aumente `CACHE = "grito-art-v1"` em `sw.js` para `v2`.
